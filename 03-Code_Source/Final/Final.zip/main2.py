import time,math,struct,gc
from machine import Pin, SPI,I2C
from pyb import LED,delay,Accel,ADC,Pin,Timer,Switch,LED,RTC
from random import randint
from LPS22 import LPS22
from rotary_tim import Encoder
from ST7735 import *

terminalfont={"Width":6, "Height":8, "Start":32, "End":127, "Data":bytearray(open('fnt.bin','rb').read())}

# Hw init
sw = Switch()
acc = Accel()
i2c = I2C(2)
lps22 = LPS22(i2c)
spi = SPI(2, baudrate=60000000, polarity=0, phase=0)
t = TFT(spi, aDC="Y3", aReset="Y4",aCS='Y5')
t.initb2()
t.fill(0)

#########################################################################################################

def level_sensors_app():
    t.fill(t.BLACK)
    while True and not click:
        x,y,z = acc.filtered_xyz()
        print("x:%i y:%i z:%i" %(x,y,z))
        t.fillrect((0,80),(128,25),TFT.BLACK)
        t.fillrect((55,38),(35,100),TFT.BLACK)
        t.fillrect((64,80),(z//2,3),TFT.PURPLE)
        t.fillrect((64,80),(3,y//2),TFT.PURPLE)
        t.text((64+z//2,85),'%s' % z,0xFFFF,terminalfont,1)
        t.text((70,80+y//2),'%s' % y,0xFFFF,terminalfont,1)
        time.sleep(0.07)
        if sw(): return True

#########################################################################################################

class Ball:
    def __init__(self,max_x=128,max_y=128,color=None):
        self.max_x = max_x
        self.max_y = max_y
        self.x = randint(10,max_x-10)
        self.y = randint(10,max_y-10)
        self.xs = randint(-5,5)
        self.ys = randint(-5,5)
        if self.xs == 0: self.xs = 2
        if self.ys == 0: self.ys = 2

        if color is None:
            self.color = TFT.COLORS[randint(0,len(TFT.COLORS)-1)]

    def __eq__(self, other):
        if  int(self.x-1) <= int(other.x) <= int(self.x+1) and int(self.y-1) <= int(other.y) <= int(self.y+1): return True
        return False

    def collision(self,b):
        a = self
        if self == b:
            a.xs = -a.xs ; a.ys = -a.ys
            b.xs = -b.xs ; b.ys = -b.ys

    def update(self):
        self.x += self.xs
        self.y += self.ys
        if self.x < 5 or self.x >= self.max_x-5: self.xs = -self.xs
        if self.y < 5 or self.y >= self.max_y-5: self.ys = -self.ys
        return int(self.x),int(self.y)


def balls_app():
    balls = [Ball()for i in range(15)]
    collision = []

    for i, b in enumerate(balls): # possible collision (avoid duplicates)
        for s in balls[i + 1:]:
            collision.append([b,s])

    while True:
        for b in balls:
            t.fillrect((int(b.x), int(b.y)), (3, 3),0)
            x, y = b.update()
            t.fillrect((x, y), (3, 3),b.color)
        for a,b in collision: a.collision(b)
        if sw() or click: return True

#########################################################################################################

reordered = b''
def bouncing_logo_app():
    global reordered
    gc.collect()
    if reordered == b'':
        bmp = open('ST_40.bmp','rb')
        data = bmp.read(54)
        bm,file_size,x1,x2,h54,h40,w,h,layers,bits_per_pixel,compression ,x3,res_h,res_v,x7,x8 = struct.unpack("<HLHHLLLLHHLLLLLL", data[:54])
        assert bm == 0x4D42, "bad header 1"
        assert h54 == 54, "bad header 2"
        assert h40 == 40, "bad header 3"
        assert layers == 1, "bad header 4"
        assert bits_per_pixel == 24, "bad header 6"
        assert compression == 0, "bad header 7"

        line_size_in_bytes = bits_per_pixel * w//8
        lines = bmp.read() # read all data as bytes

        all_pixels = [ (TFTColor(lines[i*3+2],lines[i*3+1],lines[i*3])) for i in range(w*h) ] # generate pixels
        del lines
        all_pixels = struct.pack( '>%dH' % (w*h), *all_pixels) # pack as bytearray of RGB565
        for y in range(h): # swap verticaly lines for LCD
            reordered += all_pixels[(h-y)*w*2:(h-y+1)*w*2]
        del  all_pixels
        gc.collect()
    else:
        bmp = open('ST_40.bmp','rb')
        data = bmp.read(54)
        bm,file_size,x1,x2,h54,h40,w,h,layers,bits_per_pixel,compression ,x3,res_h,res_v,x7,x8 = struct.unpack("<HLHHLLLLHHLLLLLL", data[:54])
    i,j = (randint(0,20),randint(0,20)) # random pos and move
    inc_i = 1+randint(5,9)/16
    inc_j = 1+randint(5,9)/16
    
    bg = 0xFFFF
    t.fill(bg)
    while True:
        t.image( int(i),int(j), int(w-1+0+i),int(h-1+j), reordered)
        t.rect((int(i)-1,int(j)-1),(w+2,h+2),bg) # cleanup border
        i += inc_i
        j += inc_j
        if i >= 128-w or i <= 1:
            inc_i = - inc_i
        if j >= 128-h or j <= 1:
            inc_j = - inc_j
        pyb.delay(10)
        if sw() or click:
            gc.collect()
            return True

#########################################################################################################

MAX_ITER = const(100)
WIDTH = const(128)
HEIGHT = const(128) 
RE_START = const(-2)
RE_END = const(1)
IM_START = -1.5
IM_END = 1.5

@micropython.native
def mandelbrot(c):
    z = n = 0
    while abs(z) <= 2 and n < MAX_ITER:
        z = z*z + c
        n += 1 
    return n 
  
@micropython.native
def hsv_to_rgb(h, s, v):
    if s == 0.0: v*=255; return (v, v, v)
    i = int(h*6) 
    f = (h*6.)-i; p,q,t = int(255*(v*(1.-s))), int(255*(v*(1.-s*f))), int(255*(v*(1.-s*(1.-f)))); v*=255; i%=6
    if i == 0: return (v, t, p)
    if i == 1: return (q, v, p)
    if i == 2: return (p, v, t)
    if i == 3: return (p, q, v)
    if i == 4: return (t, p, v)
    if i == 5: return (v, p, q)

def mandel_app():
    t0 = time.time()
    for x in range(0, WIDTH):
        for y in range(0, HEIGHT):
            c = complex(RE_START + (x / WIDTH) * (RE_END - RE_START), IM_START + (y / HEIGHT) * (IM_END - IM_START)) # Convert pixel coordinate to complex number
            m = mandelbrot(c)             # Compute the number of iterations
            hue = m/255 # The color depends on the number of iterations
            saturation = 1
            value = 1 if m < MAX_ITER else 0
            r,g,b= hsv_to_rgb(hue,saturation,value) # Plot the point
            color = TFTColor(r,g,b)
            t.pixel((x,y),color)
            if sw() or click: return True
            
    while True:
        time.sleep(0.2)
        if sw() or click: return True

#########################################################################################################
def colorTemp(i):
    i = int(round(i,0))
    return TFTColor( 7*i, 0, 255-7*i )

def meteo_app():
    t.fill(t.WHITE)
    last_temp = last_press = None
    x0 = 20 ; w0 = 6 
    y0 = 10 ; h0 = 100
    r0 = 8
    while True:
        if sw() or click: return True
        temp = round(lps22.temperature(),1)
        press = round(lps22.pressure(),0)
        if last_temp == temp and last_press == press:
            time.sleep(0.2)
            continue
        last_temp = temp
        last_press = press
        h = int(round(temp*3,0))  # hauteur rouge 
        t.fill(t.WHITE)  # clear
        t.fillrect((x0, y0), (w0,h0), t.BLACK)
        t.fillrect((x0+1, y0-1), (w0-2,1), t.BLACK) # haut arrondi
        t.fillcircle((int(x0-w0+r0), y0+h0), r0, t.RED)
        t.fillrect((x0, (y0+h0)-h), (w0, h), t.RED )
        t.text((x0+w0+5, (y0+h0)-h-6), '%3.1fC ' % temp, colorTemp(temp), terminalfont, 2)
        t.text((50, 105), '%dmB ' % press, t.BLUE, terminalfont, 2)
#########################################################################################################

def rect_fall_app():
    t.fill(0)
    t.setvscroll(2,2)
    i = 0
    while True:
        x,y = randint(1,110),randint(1,110)
        w,h = randint(2,50),randint(2,50)
        r,g,b = randint(0,200),randint(0,200),randint(0,200)
        t.fillrect((x,y),(w,h),TFTColor(r,g,b))
        t.vscroll(i)
        i = (i+1)%128
        time.sleep(0.020)
        if sw() or click: break
    t.vscroll(0)


#########################################################################################################

SCR_SCALE = 4
class Snake:
    LEFT =  1
    RIGHT = 2
    DOWN =  3
    UP =    4
    DIRECTIONS = [UP,LEFT,RIGHT,DOWN]
    MIAMS = 10

    XMAX = 128 // SCR_SCALE + 1 
    YMAX = 128 // SCR_SCALE + 1

    def __init__(self,x=2,y=5):
        self.init(x,y)

    def init(self,x,y):
        self.body = [(x,y),(x+1,y),(x+2,y),(x+3,y)]
        self.last_direction = self.RIGHT
        self.miam = [(randint(1,self.XMAX),randint(1,self.YMAX)) for i in range(self.MIAMS)]
        t.fill(0) # clear

    def check(self):
        x,y = self.body[-1]
        try:
            for pos in self.body[:-2]:
                assert pos != (x,y), 'Cannibal !'
            assert 0 <= x <= self.XMAX, "PAF"
            assert 0 <= y <= self.YMAX, "POUF"
        except Exception as e:
            t.text((20,20),str(e), 0xFFFF,terminalfont,1)
            delay(1000)
            t.fill(0)
            return -1

        if (x,y) in self.miam:
            miam = None
            while miam in [None] + self.body + [self.miam] + [(0,0),(0,1),(0,2)]:
                miam = (randint(2,self.XMAX-1),randint(2,self.YMAX-1))
            self.miam.append(miam)
            self.miam.remove((x,y))
            return 1
        return False

    def move(self,direction,draw=True,debug=False):
        for x,y in self.miam:
            t.fillrect((x * SCR_SCALE, y * SCR_SCALE), (SCR_SCALE, SCR_SCALE), 0xFFFF)

        t.fillrect((5, 5), (10, 10), 0)
        t.text((5,5),str(len(self.body)-4),0xFF00,terminalfont,1)

        x,y = self.body[-1] # get head
        if direction not in self.DIRECTIONS: direction = self.last_direction # last direction as last
        if direction == self.UP:   self.body.append((x,y-1))
        if direction == self.DOWN: self.body.append((x,y+1))
        if direction == self.LEFT: self.body.append((x-1,y))
        if direction == self.RIGHT: self.body.append((x+1,y))
        self.last_direction = direction

        if draw: # body
            t.rect((0,1),(128,128),TFT.BLUE)
            for pos in self.body:
                t.fillrect((x*SCR_SCALE, y*SCR_SCALE), (SCR_SCALE, SCR_SCALE), 0x0FF0)
            x,y = self.body[0]
            t.fillrect((x*SCR_SCALE,y*SCR_SCALE),(SCR_SCALE,SCR_SCALE),0x0)
            
        c = self.check()
        if c == 0: self.body.pop(0)
        elif c == 1:  pass # nothing
        elif c == -1: return True # dead
        return False

def snake_app():
    directions = [ Snake.RIGHT, Snake.DOWN,Snake.LEFT,Snake.UP]
    while True:
        e.position = 0
        s = Snake()
        while True:
            if s.move(direction = directions[e.position % len(directions)]): break
            delay(180-int(5*len(s.body)))  # plus vite qd le score augmente
            if sw() or click: break
        if sw() or click: break
    
    
#########################################################################################################
DICE = [[(2,2)], # 1
        [(1,1),(3,3)], # 2
        [(1,1),(3,3),(2,2)], # 3
        [(1,1),(3,3),(1,3),(3,1)], # 4
        [(1,1),(3,3),(1,3),(3,1),(2,2)], # 5
        [(1,1),(1,2),(1,3),(3,1),(3,2),(3,3)]] # 6

        
def dice(c=TFT.BLUE):
    t.fill(TFT.WHITE)
    i = randint(0,5)
    for x,y in DICE[i]:    
        offset = 25 ; scale = 40 ; size = 10
        t.fillcircle((offset+scale*(x-1),offset+scale*(y-1)),size,c)
        
def dice_app():
    T = 20
    x0,y0,z0 = acc.filtered_xyz()
    while True:
        x,y,z = acc.filtered_xyz()
        
        for i in range(5):
            dice(TFT.COLORS[randint(0,len(TFT.COLORS)-1)])
            delay(150)
        dice()
        
        t.rect((0,1),(128,128),0xF000)
        t.rect((1,2),(126,126),0xF000)
        
        while abs(y-y0) < T and abs(z0-z) < T:
            x,y,z = acc.filtered_xyz()
            delay(100)
            if sw() or click: return
            
def pong_app():
    # Dimensions et position de la raquette: Longueur, hauteur, position X,Y
    raquetteL = 4
    raquetteH = 10
    raquetteX = 1
    raquetteY = 60
    raquetteVitesse = 4
    last_posR = e.position
    balleR = 3 # Dimensions et position de la balle: Longeur, hauteur, position X,Y
    balleX = randint(40,80)
    balleY = randint(40,80)
    zoneXLow  = raquetteL+balleR # Zone de rebond de la balle
    zoneXHigh = 128 - balleR
    zoneYLow  = balleR
    zoneYHigh = 128 - balleR
    balleMoveX = balleMoveY = 1 # Sens de déplacement de la balle 
    scoreOK = scoreKO = 0 # Nombre de touches de balle 
    raquetteCouleur = TFT.WHITE

    t.fill(0) # Ecran noir
    update_score = True
    while True:
        # Gestion de la raquette 
        posR = e.position
        if posR != last_posR: # La raquette a bougé 
            last_posR = posR 
            t.fillrect((1,1),(10,128),TFT.BLACK) # On efface toute la ligne de la raquette en couleur de fond 
            inc = raquetteVitesse if e.forward else -raquetteVitesse
            if 0 <= raquetteY+inc <= 128 - raquetteH: raquetteY += inc
        t.fillrect((raquetteX,raquetteY),(raquetteL,raquetteH),raquetteCouleur) # Affichage de la raquette
            
        if update_score: # Affichage score ou autres donnees 
            t.fillrect((100,28),(10,80),TFT.BLACK) # on efface
            t.text((100,28),'%d' % scoreOK,TFT.GREEN,terminalfont,1)
            t.text((100,100),'%d' % scoreKO,TFT.RED,terminalfont,1)
            update_score = False

        # Gestion de la balle
        t.fillcircle((balleX,balleY),balleR,TFT.BLACK) # On efface la balle d'avant
        balleX = balleX + balleMoveX
        balleY = balleY + balleMoveY
        t.fillcircle((balleX,balleY),balleR,TFT.YELLOW)
        
        if 100 - balleR <= balleX <= 105 + balleR:
            if 26 < balleY < 38: update_score = True # La balle passe sur le score
            if 100 < balleY < 110: update_score = True # La balle passe sur le score
            
        if balleX >= zoneXHigh: # On atteint la limite supérieure en X: on change de sens 
            balleMoveX = -balleMoveX
        elif balleX <= zoneXLow:
            balleMoveX = randint(1,2) # nouvelle vitesse de balle 
            update_score = True # le score va changer
            # On a atteint la bas de l'écran. Il faut donc voir si la requette est là...
            if raquetteY - balleR <= balleY <= raquetteY + raquetteH + balleR:
                scoreOK += 1 # La balle est sur la raquette
                raquetteCouleur = TFT.GREEN
            else:
                scoreKO += 1 # La balle a raté la raquette
                raquetteCouleur = TFT.RED
                
        if balleY >= zoneYHigh or balleY <= zoneYLow: # On atteint les limites Y: on change de sens
            balleMoveY = -balleMoveY
            
        time.sleep(0.005)
        if sw() or click: break




#########################################################################################################
        
click = False
last_click = 0
def clicked(a):  # click molette !
    global click, last_click
    t = time.ticks_ms()
    if t - last_click < 500: return  # anti rebond
    last_click = t
    click = True
    
pin_vpp = Pin('X4',Pin.OUT)
pin_vpp.value(1)
#e = Encoder(Pin('X1',Pin.IN,Pin.PULL_NONE),Pin('X2',Pin.IN,Pin.PULL_NONE),Pin('X3',Pin.PULL_NONE),clicked)
e = Encoder(Pin('X1',Pin.IN,Pin.PULL_UP),Pin('X2',Pin.IN,Pin.PULL_UP),Pin('X3',Pin.PULL_NONE),clicked)

APPS = [
    ("ST logo",bouncing_logo_app),
    ("Meteo",meteo_app),
    ("Niveau",level_sensors_app),
    ("Mandelbrot",mandel_app),
    ("Bouncing Balls",balls_app),
    ("Snake",snake_app),
    ("Dice",dice_app),
    ("Pong",pong_app),
    ("Rect. Falls",rect_fall_app)]

def app_menu():
    global click
    global last_pos
    t.fill(0)
    scale = 1
    Y0 = 30
    X0 = 15 ; X1 = 4 ; sel = ">"
    H = 9*scale
    y = Y0 ; x = X0 - 3
    t.fill(t.BLACK)
    t.text((X0+12,Y0-20),"MENU",0x001F,terminalfont,2)
    t.rect((X0-3,Y0-23),(80,20),0x001F)
    for name,func in APPS:
        t.text((x,y),'  %s' % name,t.WHITE,terminalfont,scale,1)
        y += H
    
    last_pos = e.position % len(APPS)
    pos = 0
    init = True
    while not click:
        pos = e.position % len(APPS)
        if pos != last_pos or init:
            init = False
            t.fillrect((x,Y0+H*last_pos),(100,8),t.BLACK)
            t.text((x,Y0+H*last_pos), '  %s' % APPS[last_pos][0] ,t.WHITE,terminalfont,scale)
            t.text((x,Y0+H*pos), '> %s' % APPS[pos][0],t.RED,terminalfont,scale)
            last_pos = pos
        time.sleep_ms(100)
    click = False
    t.fill(TFT.BLACK)
    return APPS[pos][1]

#########################################################################################################

while True:
    func = app_menu()
    pos = e.position
    func()
    gc.collect()
    e.position = pos
    click = False
