import time, math, struct, gc, os
from ST7735 import *
from machine import Pin, SPI, I2C
from pyb import LED, delay, Accel, ADC, Pin, Timer, Switch, LED, RTC
from random import randint
from LPS22 import LPS22
from rotary_tim import Encoder

terminalfont = {
    "Width": 6, "Height": 8,
    "Start": 32, "End": 127,
    "Data": bytearray(open('fnt.bin', 'rb').read())}

sw = Switch()
acc = Accel()
i2c = I2C(2)
lps22 = LPS22(i2c)
spi = SPI(2, baudrate=60000000, polarity=0, phase=0)
t = TFT(spi, aDC="Y3", aReset="Y4", aCS='Y5')
t.initb2()
t.fill(t.BLACK)

last_click = 0

def clicked(a):
    global last_click
    t = time.ticks_ms()
    if t - last_click < 500: return
    last_click = t

pin_vpp = Pin('X4', Pin.OUT, value=1)  # faux vpp pour la rotary
e = Encoder(Pin('X1', Pin.IN, Pin.PULL_UP), Pin('X2', Pin.IN, Pin.PULL_UP), Pin('X3', Pin.PULL_NONE), clicked )

t.text((10, 5), "-=TEST=-", t.WHITE, terminalfont, 2)
H = 12
files = os.listdir('.')
py = len([i for i in files if i.endswith('.py')])
bin_ = len([i for i in files if i.endswith('.bin')])
bmp = len([i for i in files if i.endswith('.bmp')])
rtc = RTC()

t.text((5, 30), 'py:%s bin:%s bmp:%s' % (py, bin_, bmp), t.RED, terminalfont, 1)
cnt = 0

if 'ST_40.bmp' in files:
    reordered = b''
    bmp = open('ST_40.bmp', 'rb')
    data = bmp.read(54)
    bm, file_size, x1, x2, h54, h40, w, h, layers, bits_per_pixel, compression, x3, res_h, res_v, x7, x8 = struct.unpack("<HLHHLLLLHHLLLLLL", data[:54])
    assert bm == 0x4D42, "bad header 1"
    assert h54 == 54, "bad header 2"
    assert h40 == 40, "bad header 3"
    assert layers == 1, "bad header 4"
    assert bits_per_pixel == 24, "bad header 6"
    assert compression == 0, "bad header 7"

    line_size_in_bytes = bits_per_pixel * w // 8
    lines = bmp.read()  # read all data as bytes
    all_pixels = [(TFTColor(lines[i * 3 + 2], lines[i * 3 + 1], lines[i * 3])) for i in range(w * h)]  # generate pixels
    del lines
    all_pixels = struct.pack('>%dH' % (w * h), *all_pixels)  # pack as bytearray of RGB565
    for y in range(h):  # swap verticaly lines for LCD
        reordered += all_pixels[(h - y) * w * 2:(h - y + 1) * w * 2]
    del all_pixels
    gc.collect()
    i, j = (70, 80)
    t.image(int(i), int(j), int(w - 1 + 0 + i), int(h - 1 + j), reordered)

    del reordered
    gc.collect()
else:
    t.text((5, 93), 'ST_40.bmp missing' , t.RED, terminalfont, 1)


while True:
    h = 43
    cnt += 1
    temp, press = lps22.get()
    t.text((5, h), 't:%sC ' % temp, t.GREEN, terminalfont, 1)
    h += H
    x, y, z = acc.filtered_xyz()
    t.text((5, h), "x:%i y:%i z:%i  " % (x, y, z), t.YELLOW, terminalfont, 1)
    h += H
    t.text((5, h), "r:%i t:%i  " % (e.position, last_click), t.CYAN, terminalfont, 1)
    h += H
    t.text((5, h), "cnt:%i  " % (cnt), t.BLUE, terminalfont, 1)

    time.sleep(0.1)


